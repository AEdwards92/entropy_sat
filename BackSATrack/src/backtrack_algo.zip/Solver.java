import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import java.util.Random;

public class Solver {
	/* Holds sat problem information
	 */
	protected ProblemInstance inst;
	
	/* Partial assignment maintained but never directly used
	 * when sampling a clause, the assignment is updated
	 * the individual variables are never accessed except
	 * via a clause
	 */
	protected List<Integer> assignment;
	
	public Solver() {
		assignment = new LinkedList<Integer>();
	}
	
	public Solver(ProblemInstance sat) {
		inst = sat;
		assignment = new LinkedList<Integer>();
		initialize();
	}

	
	private void initialize() {
		// add dummy item to use 1-based indexing
		assignment.add(-1);
		for (int i = 1; i <= inst.numVars; i++) {
			if (Math.random() < 0.5) {
				assignment.add(0);
			} else {
				assignment.add(1);
			}
		}
	}
	
	private boolean satisfied() {
		boolean sat;
		for(int i = 0; i < inst.getNumClauses(); i++) {
			sat = false;
			Clause c = inst.getClause(i);
			for (int v : c.getVars()) {
				if ((v < 0 && assignment.get(-v) == 0)
				 || (v > 0 && assignment.get(v) == 1)) {
					sat = true;
					break;
				} 
			}
			if (!sat) {
				return false;
			}
		}
		return true;
	}
	
	public int solve() {
		List<Clause> unsetClauses;
		int numUnset;
		int choice;
		int step;
		Random randomGenerator = new Random();
		for (step = 0; ; step++) {
			unsetClauses = inst.getUnsetClauses();
			numUnset = unsetClauses.size();
			if (numUnset == 0) {
				System.err.println("Step: " + step);
				if (satisfied()) {
					break;
				} else {
					System.err.println("unsetClauses empty while problem not satisfied");
				}
			}
			choice = randomGenerator.nextInt(numUnset);
			Clause c = unsetClauses.get(choice);
			boolean unsat;
			// Sample V(c), make sure the resulting assignment
			// satisfies c.
			do {
				unsat = true;
				for (int v : c.getVars()) {
					if (Math.random() < 0.5) {
						assignment.set(Math.abs(v), 0);
						if (unsat && v < 0) {
							unsat = false;
						}
					} else {
						assignment.set(Math.abs(v), 1);
						if (unsat && v > 0) {
							unsat = false;
						}
					}
				}
			} while (unsat);
			
			inst.setClause(c);
			
			// Check neighboring clauses of c which are set, and if they
			// are unsatasified by current assignment, unset them
			for (int v : c.getVars()) {
				List<Integer> neighborClauseIDs = inst.occurrenceMap.get(Math.abs(v));
				for (int cid : neighborClauseIDs) {
					Clause d = inst.getClause(cid);
					if (d.isSet()) {
						unsat = true;
						for (int u : d.getVars()) {
							if ((u > 0) && (assignment.get(u) == 1) ) {
								unsat = false;
								break;
							} else if ((u < 0) && (assignment.get(-u) == 0)) {
								unsat = false;
								break;
							}
						}
						if (unsat) {
							inst.unsetClause(d);
						}
					}
				}
			}
		}
		return step;
	}
	
	public int solve(ProblemInstance sat) {
		inst = sat;
		initialize();
		return solve();
	}
	
	public static void main(String[] args) {
		String fileName = "src/Files/test750";
		ProblemInstance sat = DimacsParser.parseDimacsFile(fileName);
		Solver sol = new Solver(sat);
		
		
		int steps = sol.solve();
		if (sol.satisfied()) {
			System.out.println("Satisfied in " + steps + " steps!");
		} else {
			System.out.println("Not Satisfied!");
		}
	}
	
}
